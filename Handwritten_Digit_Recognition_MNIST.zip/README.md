# Handwritten Digit Recognition (MNIST)

## Synopsis
This project focuses on recognizing handwritten numbers from images. It uses the MNIST dataset, which contains 28×28 grayscale images of handwritten digits from 0 to 9. A neural-network classification model is trained to recognize the digit shown in a new image.

## Objectives
- Understand image-based datasets.
- Explore handwritten digit images.
- Prepare image data for training.
- Train a classification model.
- Predict handwritten digits.
- Evaluate prediction accuracy.

## Tools
Python, NumPy, Matplotlib, TensorFlow/Keras

## Dataset
The MNIST dataset is automatically downloaded by Keras the first time the program runs.

- Training images: 60,000
- Testing images: 10,000
- Image size: 28 × 28 pixels
- Classes: digits 0 through 9

## Methodology
1. Load the MNIST dataset.
2. Explore the image and label dimensions.
3. Normalize pixel values from 0–255 to 0–1.
4. Convert digit labels to one-hot encoded vectors.
5. Build a neural network using Keras.
6. Train the model for 5 epochs.
7. Evaluate the model on the test dataset.
8. Predict sample handwritten digits.
9. Visualize predictions and training accuracy.

## Model Architecture
- Flatten layer
- Dense layer: 128 neurons, ReLU activation
- Dense layer: 64 neurons, ReLU activation
- Output layer: 10 neurons, Softmax activation

## Evaluation
The program reports:
- Test accuracy
- Test loss
- Actual vs predicted digits for sample images
- Training and validation accuracy

It also creates:
- `mnist_predictions.png`
- `training_accuracy.png`

## How to Run
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   pip install -r requirements.txt
4. Run:
   python mnist_digit_recognition.py

## Notes
- TensorFlow/Keras downloads MNIST automatically when required.
- Training time depends on your computer.
- A GPU is not required for this small educational model, although it can speed up training.
